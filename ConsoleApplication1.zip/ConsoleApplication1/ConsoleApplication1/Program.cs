﻿using System;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Auto auto1 = new Auto();
            auto1.Kiirenda(); // kiirusele 10 juurde
            auto1.Kiirenda(23); // anname aga gaasi
            Console.WriteLine(auto1);
            Console.WriteLine();
            

            VeoAuto veokas = new VeoAuto();
            veokas.Kiirenda(-20); // tagurdame 20 km/h
            Console.WriteLine(veokas);
            Console.WriteLine();

            veokas.HakkaKallutama(); // ei saa kallutades sõita!
            Console.WriteLine(veokas);
            Console.WriteLine();


            Auto rallikas = new Auto();
            rallikas.Kiirenda(150); // ei saa sõita nii kiiresti ...
            rallikas.AvaUksed(); //  ... ja uksed on ka lahti, huligaan!
            Console.WriteLine(rallikas);
            Console.WriteLine();
        }


    }

    public abstract class MootorSoiduk
    {
        private int _kiirus;
        private int _maxKiirus = 20;


        public int MaxKiirus
        {
            get { return _maxKiirus; }
            set { _maxKiirus = value; }
        }

        protected MootorSoiduk(int maxKiirus)
        {
            this._maxKiirus = maxKiirus;
        }

        protected MootorSoiduk()
        {

        }

        public virtual void Kiirenda(int kiirendus)
        {
            _kiirus = Math.Abs(_kiirus);
            if ((_kiirus + kiirendus) <= _maxKiirus)
            {
                _kiirus += kiirendus;
            }
        }

        public virtual void Kiirenda()
        {
            _kiirus = Math.Abs(_kiirus);
            if ((_kiirus + 10) <= _maxKiirus)
            {
                _kiirus += 10;
            }
        }

        public void Stop()
        {
            _kiirus = 0;
        }

        public virtual string HetkeSeis()
        {
            if (_kiirus > 0)
            {
                return "Sõiduk sõidab kiirusega: " + _kiirus;
            }
            else if (_kiirus < 0)
            {
                return "Sõiduk tagurdab kiirusega: " + Math.Abs(_kiirus);
            }
            else
            {
                return "Sõiduk seisab!";
            }
        }

        public override string ToString()
        {
            return HetkeSeis();
        }
        
    }

    public class Auto : MootorSoiduk
    {
        private bool _uksedAvatud;

        public Auto(int maxKiirus) : base(maxKiirus)
        {

        }

        public Auto() : base(100)
        {
            
        }

        public void AvaUksed()
        {
            _uksedAvatud = true;
        }

        public void SulgeUksed()
        {
            _uksedAvatud = false;
        }

        public override void Kiirenda(int kiirendus)
        {
            if (!_uksedAvatud)
            {
                base.Kiirenda(kiirendus);
            }
        }

        public override string HetkeSeis()
        {
            return base.HetkeSeis() + " Uksed avatud:" + _uksedAvatud;
        }

        public override string ToString()
        {
            return HetkeSeis();
        }
    }

    public class VeoAuto : Auto
    {
        private bool _kallutab;

        public VeoAuto() : base(70)
        {

        }

        public void HakkaKallutama()
        {
            Stop();
            _kallutab = true;
        }

        public override void Kiirenda(int kiirenda)
        {
            if (!_kallutab)
            {
                base.Kiirenda(kiirenda);
            }
        }

        public override string HetkeSeis()
        {
            return base.HetkeSeis() + " kallutab: " + _kallutab;
        }

        public override string ToString()
        {
            return HetkeSeis();
        }
    }
}
